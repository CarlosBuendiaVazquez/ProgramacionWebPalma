<html>
<head>
	<title>Mi primer script en php</title>
</head>

<body>
<?php
ECHO "Hola! Este es mi primer script en PHP <BR>";

//Esto es una linea de comentario

#Esto también es una linea de comentario

/* Esto también es un
bloque de mas de una linea de comentarios */


$vartext="Hola! Ahora estoy usando variables para guardar texto<BR>";
echo $vartext;
$varnum1=5;
$varnum2=6;
$res=$varnum1+$varnum2;
echo "El resultado de la suma de $varnum1 y $varnum2 es igual a =$res";
?> 
</body>
</html>